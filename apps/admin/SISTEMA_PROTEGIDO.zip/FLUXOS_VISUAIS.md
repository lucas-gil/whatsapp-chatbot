# 🎬 Fluxo Visual Completo do Chatbot

## 1️⃣ Entrada do Usuário

```
┌──────────────────────────────────────────┐
│         Usuário no WhatsApp              │
│                                          │
│  📱 "Oi, tudo bem?"                     │
└─────────────────┬──────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│    Cloud API WhatsApp (Meta)             │
│    Recebe mensagem POST /webhook         │
└─────────────────┬──────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│  API NodeJS (Fastify)                   │
│  - Valida assinatura webhook            │
│  - Parse mensagem                       │
└─────────────────┬──────────────────────┘
```

---

## 2️⃣ Processamento (FlowService)

```
┌──────────────────────────────────────────┐
│  FlowService.processMessage()            │
│                                          │
│  1. Encontrar/criar Contato             │
│  2. Encontrar/criar Conversa            │
│  3. Salvar mensagem recebida            │
│  4. Verificar comando global            │
│  5. Navegar estado atual                │
└─────────────────┬──────────────────────┘
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
    [Comando Global]    [State Machine]
    - menu                welcome
    - suporte              device_selection
    - voltar              installation_instructions
    - cancelar            awaiting_installation_proof
                          main_menu
                          contratar_menu
                          renovacao
                          suporte
```

---

## 3️⃣ Resposta com IA (AIService)

```
┌──────────────────────────────────────────┐
│  AIService.generateResponse()            │
│                                          │
│  1. Buscar documentos relevantes (RAG)  │
│  2. Manter histórico por usuário        │
│  3. Chamar OpenAI/Gemini com contexto   │
│  4. Retornar resposta                   │
└─────────────────┬──────────────────────┘
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
    Base de Conhecimento  OpenAI/Gemini
    - FAQ                 - gpt-4-turbo
    - Instalações        - Gemini Pro
    - Políticas
```

---

## 4️⃣ Armazenamento (Prisma)

```
┌──────────────────────────────────────────┐
│  PostgreSQL (Banco de Dados)             │
│                                          │
│  Tabelas:                                │
│  ├── Contact (Usuários)                 │
│  ├── Conversation (Chats)               │
│  ├── Message (Mensagens)                │
│  ├── Subscription (Assinaturas)         │
│  ├── Payment (Pagamentos)               │
│  ├── Ticket (Suporte)                   │
│  ├── Plan (Planos)                      │
│  ├── KnowledgeBase (FAQ)                │
│  └── ... (9 tabelas no total)           │
└─────────────────┬──────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│  Redis (Cache/Sessões)                   │
│  - Histórico de IA                      │
│  - Filas de processamento               │
└──────────────────────────────────────────┘
```

---

## 5️⃣ Resposta ao Usuário

```
┌──────────────────────────────────────────┐
│  WhatsAppService.send*()                 │
│                                          │
│  Opções:                                 │
│  - sendText()          → Texto           │
│  - sendButtonMessage() → Botões (≤3)     │
│  - sendListMessage()   → Lista           │
│  - sendImage()         → Imagem          │
│  - sendVideo()         → Vídeo           │
└─────────────────┬──────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│  Cloud API WhatsApp                      │
│  POST /messages                          │
└─────────────────┬──────────────────────┘
                  │
                  ▼
┌──────────────────────────────────────────┐
│  📱 Usuário recebe no WhatsApp           │
│                                          │
│  Bot: "Bem-vindo! 👋                    │
│        Escolha seu dispositivo:          │
│        📱 SMARTPHONE                     │
│        📺 TV SMART                       │
│        📦 TV BOX"                        │
└──────────────────────────────────────────┘
```

---

## 💳 Fluxo de Pagamento

```
Usuário escolhe: "CONTRATAR PLANO"
         │
         ▼
Bot lista: Básico (R$29,99) | Premium (R$59,99)
         │
         ▼
Usuário clica: "Premium"
         │
         ▼
PaymentService.createPreference()
         │
         ├─→ Mercado Pago API
         │
         ▼
Link de pagamento gerado
         │
         ▼
Bot envia link: "💳 Clique para pagar"
         │
         ▼
Usuário abre link → Paga (PIX/Cartão)
         │
         ▼
Webhook Mercado Pago: payment.approved
         │
         ▼
Subscription.status = "active"
         │
         ▼
Bot envia: "Bem-vindo! ✅ Seu acesso foi liberado!"
```

---

## 🎫 Fluxo de Suporte

```
Usuário: "Tenho um problema"
         │
         ▼
Bot: "Qual é a categoria?"
  - Instalação
  - Erro técnico
  - Pagamento
  - Outro
         │
         ▼
Usuário escolhe: "Erro técnico"
         │
         ▼
Bot: "Descreva o erro"
         │
         ▼
Usuário: "App está travando"
         │
         ▼
Bot cria Ticket:
  - category: "erro_tecnico"
  - status: "open"
  - priority: "normal"
         │
         ▼
Notificar Suporte (via Telegram/Email)
         │
         ▼
Admin vê no Dashboard
         │
         ▼
Admin responde via Chat
         │
         ▼
Bot encaminha resposta ao usuário
```

---

## 📊 Dashboard Admin

```
┌─────────────────────────────────────────────────────────┐
│                     ADMIN DASHBOARD                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📊 KPIs (Real-time)                                   │
│  ┌──────────┬──────────┬──────────┬──────────┐         │
│  │ 126      │ 34       │ 12       │ 28       │         │
│  │ Contatos │ Chats    │ Tickets  │ Clientes │         │
│  │          │ Ativos   │ Abertos  │          │         │
│  └──────────┴──────────┴──────────┴──────────┘         │
│                                                         │
│  📱 Contatos Recentes                                  │
│  ┌─────────────────────────────────────────────┐       │
│  │ Telefone     │ Nome      │ Dispositivo │ Status  │   │
│  ├─────────────────────────────────────────────┤       │
│  │ 11 99998888 │ João      │ SMARTPHONE  │ Lead    │   │
│  │ 11 99997777 │ Maria     │ TV SMART    │ Cliente │   │
│  │ 11 99996666 │ Pedro     │ -           │ Prospect│   │
│  └─────────────────────────────────────────────┘       │
│                                                         │
│  [Listar Tickets] [Gerenciar Planos] [Históricos]     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🔄 Estado da Conversa (State Machine)

```
START
  │
  ▼
┌─────────────────────────┐
│ welcome                 │  → Envia boas-vindas + vídeo
│ (Step 1)                │     Oferece: Qual dispositivo?
└────────────┬────────────┘
             │
    ┌────────┴────────┐
    ▼                 ▼
[Smartphone]      [TV Smart]
    │                 │
    ▼                 ▼
┌──────────────────────────┐
│ device_selection         │  → Envia instruções
│ (Step 2)                 │     Oferece: Instalou?
└────────────┬─────────────┘
             │
    ┌────────┴────────┐
    ▼                 ▼
[Sim]             [Não]
    │                 │
    ▼                 ▼
┌────────────────────────────────────────┐
│ awaiting_installation_proof            │
│ (Step 3)                               │  → Aguarda print/foto
└────────────┬─────────────────────────┘
             │
    ┌────────┴────────┐
    ▼                 ▼
[Imagem OK]      [Erro/Ajuda]
    │                 │
    ▼                 ▼
┌──────────────────────────────────────┐
│ main_menu                            │  → Menu principal
│ (Step 4)                             │     Oferece: Contratar/Renovar/Suporte
└─────────┬────────────────────────────┘
          │
   ┌──────┼──────┐
   ▼      ▼      ▼
 [Contratar] [Renovar] [Suporte]
   │          │         │
   ▼          ▼         ▼
[Payment]  [Check]   [Ticket]
   │          │         │
   ▼          ▼         ▼
[End]      [End]      [End]
```

---

## 🔐 Segurança

```
Mensagem recebida
  │
  ▼
Validar assinatura webhook
  │ (x-hub-signature-256)
  ▼
Verificar Verify Token
  │
  ▼
Limpar número de telefone
  │ (apenas dígitos)
  ▼
Validar entrada de usuário
  │
  ▼
Rate limit (Redis)
  │
  ▼
Procesar com segurança
```

---

## 📈 Escalabilidade

```
Localmente (Desenvolvimento)
├── PostgreSQL local
├── Redis local
└── API + Admin em localhost

Docker (Teste)
├── PostgreSQL container
├── Redis container
└── API/Admin containers

Produção (Railway/Render)
├── PostgreSQL RDS
├── Redis Cloud
├── API scalável
└── Admin CDN
```

---

**Leia os documentos para configuração detalhada! 📚**
