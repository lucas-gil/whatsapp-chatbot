/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  typescript: {
    tsconfigPath: './tsconfig.json',
  },
  productionBrowserSourceMaps: false,
  poweredByHeader: false,
  compress: true,
}

module.exports = nextConfig
