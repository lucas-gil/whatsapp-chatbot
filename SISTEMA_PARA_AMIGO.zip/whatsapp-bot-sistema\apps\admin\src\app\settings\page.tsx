'use client';

import { useState, useEffect } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { Save, AlertCircle, CheckCircle } from 'lucide-react';

interface Settings {
  businessName: string;
  businessPhone: string;
  businessEmail: string;
  webhookUrl: string;
  apiBaseUrl: string;
  maxRetries: number;
  retryInterval: number;
  autoReply: boolean;
  autoReplyMessage: string;
  messageTimeout: number;
  enableNotifications: boolean;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings>({
    businessName: 'IPTV ChatBot',
    businessPhone: '55 11 98765-4321',
    businessEmail: 'admin@iptvchatbot.com',
    webhookUrl: 'https://webhook.site/seu-webhook',
    apiBaseUrl: process.env.NEXT_PUBLIC_API_URL || '',
    maxRetries: 3,
    retryInterval: 5000,
    autoReply: true,
    autoReplyMessage: 'Obrigado pela mensagem! Responderemos em breve.',
    messageTimeout: 30000,
    enableNotifications: true,
  });

  const [savedMessage, setSavedMessage] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    // Carregar configurações do localStorage
    const saved = localStorage.getItem('appSettings');
    if (saved) {
      try {
        setSettings(JSON.parse(saved));
      } catch (error) {
        console.error('Erro ao carregar configurações:', error);
      }
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    setSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simular salvamento
      localStorage.setItem('appSettings', JSON.stringify(settings));
      setSavedMessage('✓ Configurações salvas com sucesso!');
      setTimeout(() => setSavedMessage(''), 3000);
    } catch (error) {
      console.error('Erro ao salvar:', error);
      setSavedMessage('✗ Erro ao salvar configurações');
      setTimeout(() => setSavedMessage(''), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header />
        
        <main className="flex-1 overflow-auto">
          <div className="max-w-5xl mx-auto p-6">
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-white mb-2">Configurações</h1>
              <p className="text-slate-400">Gerencie as configurações gerais do sistema</p>
            </div>

            {/* Mensagem de Sucesso/Erro */}
            {savedMessage && (
              <div className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
                savedMessage.includes('sucesso') 
                  ? 'bg-emerald-900/20 border border-emerald-500/30 text-emerald-400' 
                  : 'bg-red-900/20 border border-red-500/30 text-red-400'
              }`}>
                {savedMessage.includes('sucesso') ? (
                  <CheckCircle size={20} />
                ) : (
                  <AlertCircle size={20} />
                )}
                {savedMessage}
              </div>
            )}

            <div className="space-y-8">
              {/* Seção: Informações do Negócio */}
              <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                  <div className="w-1 h-6 bg-emerald-500 rounded"></div>
                  Informações do Negócio
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Nome do Negócio
                    </label>
                    <input
                      type="text"
                      name="businessName"
                      value={settings.businessName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Telefone Principal
                    </label>
                    <input
                      type="tel"
                      name="businessPhone"
                      value={settings.businessPhone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Email de Contato
                    </label>
                    <input
                      type="email"
                      name="businessEmail"
                      value={settings.businessEmail}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
              </section>

              {/* Seção: Configurações de API */}
              <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                  <div className="w-1 h-6 bg-emerald-500 rounded"></div>
                  Configurações de API
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      URL Base da API
                    </label>
                    <input
                      type="url"
                      name="apiBaseUrl"
                      value={settings.apiBaseUrl}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Máximo de Tentativas
                    </label>
                    <input
                      type="number"
                      name="maxRetries"
                      value={settings.maxRetries}
                      onChange={handleInputChange}
                      min="1"
                      max="10"
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Intervalo de Retry (ms)
                    </label>
                    <input
                      type="number"
                      name="retryInterval"
                      value={settings.retryInterval}
                      onChange={handleInputChange}
                      min="1000"
                      step="1000"
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Timeout de Mensagem (ms)
                    </label>
                    <input
                      type="number"
                      name="messageTimeout"
                      value={settings.messageTimeout}
                      onChange={handleInputChange}
                      min="5000"
                      step="5000"
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      URL do Webhook
                    </label>
                    <input
                      type="url"
                      name="webhookUrl"
                      value={settings.webhookUrl}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
              </section>

              {/* Seção: Resposta Automática */}
              <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                  <div className="w-1 h-6 bg-emerald-500 rounded"></div>
                  Resposta Automática
                </h2>

                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <input
                      type="checkbox"
                      name="autoReply"
                      checked={settings.autoReply}
                      onChange={handleInputChange}
                      className="w-5 h-5 rounded bg-slate-800 border-slate-700 text-emerald-500 cursor-pointer"
                    />
                    <label className="text-sm font-medium text-slate-300 cursor-pointer">
                      Ativar Resposta Automática
                    </label>
                  </div>

                  {settings.autoReply && (
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Mensagem de Resposta Automática
                      </label>
                      <textarea
                        name="autoReplyMessage"
                        value={settings.autoReplyMessage}
                        onChange={handleInputChange}
                        rows={4}
                        className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none resize-none"
                      />
                    </div>
                  )}
                </div>
              </section>

              {/* Seção: Notificações */}
              <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                  <div className="w-1 h-6 bg-emerald-500 rounded"></div>
                  Notificações
                </h2>

                <div className="flex items-center gap-4">
                  <input
                    type="checkbox"
                    name="enableNotifications"
                    checked={settings.enableNotifications}
                    onChange={handleInputChange}
                    className="w-5 h-5 rounded bg-slate-800 border-slate-700 text-emerald-500 cursor-pointer"
                  />
                  <label className="text-sm font-medium text-slate-300 cursor-pointer">
                    Ativar Notificações do Sistema
                  </label>
                </div>
              </section>

              {/* Botão Salvar */}
              <div className="flex justify-end">
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-600 text-white font-semibold rounded-lg transition-colors"
                >
                  <Save size={20} />
                  {isSaving ? 'Salvando...' : 'Salvar Configurações'}
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
